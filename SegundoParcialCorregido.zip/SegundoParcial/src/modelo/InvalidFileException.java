package modelo;

public class InvalidFileException extends Exception {
    public InvalidFileException(){
        super("File contains invalid or corrupted data");
    }
}
