package modelo;

import java.io.Serializable;

public class Libro implements Comparable<Libro>, CSVSerializable<Libro>, Serializable {
    private int id;
    private String autor;
    private String titulo;
    private Categoria categoria;
    private static final long serialVersionUID = 1L;
    
    public Libro(int id, String titulo, String autor, Categoria categoria){
        this.id = id;
        this.autor = autor;
        this.titulo = titulo;
        this.categoria = categoria;
    }

    public int getId(){ return id; }
    public String getTitulo(){ return titulo; }
    public Categoria getCategoria(){ return categoria; }

    @Override
    public int compareTo(Libro obj){
        return Integer.compare(id, obj.getId());
    }

    public String toCSV(){
        return String.format("%d,%s,%s,%s\n", id, titulo, autor, categoria);
    }
    
    public static Libro fromCSV(String line){
        String[] data = line.split(",");
        Libro toReturn = new Libro(Integer.parseInt(data[0]), data[1], data[2], Categoria.valueOf(data[3].toUpperCase()));
        return toReturn;
    }

    @Override
    public String CSVTitles(){
        return "id,titulo,autor,categoria\n";
    }
    
    @Override
    public String toString(){
        return String.format("{id:%d, titulo:%s, autor:%s, categoria:%s}", id, titulo, autor, categoria);
    }
}
