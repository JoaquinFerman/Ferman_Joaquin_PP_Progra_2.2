package segundoParcial;

import java.io.IOException;

import modelo.*;

public class Main{
    public static void main(String[] args) {
        try {
        // Crear un inventario de libros
        Inventario<Libro> inventarioLibros = new Inventario<>();
        inventarioLibros.agregar(new Libro(1, "1984", "George Orwell", Categoria.ENTRETENIMIENTO));
        inventarioLibros.agregar(new Libro(2, "El señor de los anillos", "J.R.R.Tolkien", Categoria.LITERATURA));
        inventarioLibros.agregar(new Libro(3, "Cien años de soledad", "GabrielGarcía Márquez", Categoria.LITERATURA));
        inventarioLibros.agregar(new Libro(4, "El origen de las especies", "CharlesDarwin", Categoria.CIENCIA));
        inventarioLibros.agregar(new Libro(5, "La guerra de los mundos", "H.G.Wells", Categoria.ENTRETENIMIENTO));
        // Mostrar todos los libros en el inventario
        System.out.println("Inventario de libros:");
        inventarioLibros.paraCadaElemento(n -> System.out.println(n));

        // Filtrar libros por categoría LITERATURA
        System.out.println("\nLibros de la categoría LITERATURA:");
        inventarioLibros.filtrar(n -> (n.getCategoria().equals(Categoria.LITERATURA)))
        .forEach(libro -> System.out.println(libro));

        // Filtrar libros cuyo título contiene "1984"
        System.out.println("\nLibros cuyo título contiene '1984':");
        inventarioLibros.filtrar(n -> (n.getTitulo().contains("1984"))) // no encontre el contains
        .forEach(libro -> System.out.println(libro));

        // Ordenar libros de manera natural (por id)
        System.out.println("\nLibros ordenados de manera natural (por id):");
        inventarioLibros.ordenar();
        inventarioLibros.paraCadaElemento(libro -> System.out.println(libro));

        // Ordenar libros por título utilizando un Comparator
        System.out.println("\nLibros ordenados por título:");
        inventarioLibros.ordenar((l1, l2) -> (l1.getTitulo().compareTo(l2.getTitulo())));
        inventarioLibros.paraCadaElemento(libro -> System.out.println(libro));

        // Guardar el inventario en un archivo binario
        inventarioLibros.guardarEnArchivo("data/libros.dat");
        // Cargar el inventario desde el archivo binario
        Inventario<Libro> inventarioCargado = new Inventario<>();
        inventarioCargado.cargarDesdeArchivo("data/libros.dat");
        System.out.println("\nLibros cargados desde archivo binario:");
        inventarioCargado.paraCadaElemento(libro -> System.out.println(libro));
        // Guardar el inventario en un archivo CSV
        inventarioLibros.guardarEnCSV("data/libros.csv");
        // Cargar el inventario desde el archivo CSV
        inventarioCargado.cargarDesdeCSV("data/libros.csv");
        System.out.println("\nLibros cargados desde archivo CSV:");
        inventarioCargado.paraCadaElemento(libro -> System.out.println(libro));
        } catch (IOException | ClassNotFoundException e) {
        System.err.println("Error: " + e.getMessage());
        }
    }
}