package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends CSVSerializable<T> & Comparable<T>> implements Inventariable<T>{
    // hice que solo puedan ser comparables para evitarme problemas
    List<T> elementos;

    public Inventario(){
        this.elementos = new ArrayList<>();
    }

    @Override
    public void agregar(T obj){
        elementos.add(obj);
    }

    @Override
    public T get(int i){
        return elementos.get(i);
    }

    @Override
    public void remover(T obj){
        elementos.remove(obj);
    }

    @Override
    public void ordenar(Comparator<T> comp){
        Collections.sort(elementos, comp);
    }

    @Override
    public void ordenar(){
        Collections.sort(elementos);
        // Iba a usar el sort normal pero no aparecia disponible el sort sin entrada de comparator
    }

    public void paraCadaElemento(Consumer<T> accion){
        for(T obj : elementos){
            accion.accept(obj);
        }
    }

    @Override
    public List<T> filtrar(Predicate<T> comp){
        List<T> aux = new ArrayList<>();
        for(T obj : elementos){
            if(comp.test(obj)){
                aux.add(obj);
            }
        }
        return aux;
    }

    public void guardarEnCSV(String path){
        File file = new File(path);

        try{
            if(!file.exists()){
                file.createNewFile();
            }
        } catch (IOException ex){
            System.out.println("Error while creating file");
        }

        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write(elementos.get(0).CSVTitles());
            for(T obj : elementos){
                bw.write(obj.toCSV());
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    public List<T> cargarDesdeCSV(String path, Function<String, T> f){
        List<T> toReturn = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(path))){
            String line;
            br.readLine();
            while((line = br.readLine()) != null){
                if(line.endsWith("\n")){
                    line = line.substring(line.length()-1);
                }
                
                T obj = f.apply(line);
                toReturn.add(obj);
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }

    public void guardarEnArchivo(String path){
    try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(path))){
        out.writeObject(elementos);
        } catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException{
        try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            elementos = (List<T>) input.readObject();
            System.out.println("Objeto recuperado");
        } catch(IOException ex){
            throw new IOException();
        } catch(ClassNotFoundException ex){
            throw new ClassNotFoundException();
        }
    }
}
