package servicio;

public interface CSVSerializable<T> {
    String CSVTitles();
    String toCSV();
}
