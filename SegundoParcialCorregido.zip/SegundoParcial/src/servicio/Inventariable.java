package servicio;

import java.util.function.Predicate;
import java.util.Comparator;
import java.util.List;

public interface Inventariable<T extends CSVSerializable<T>> {
    void agregar(T obj);
    void remover(T obj);
    T get(int i);
    List<T> filtrar(Predicate<T> p);
    void ordenar();
    void ordenar(Comparator<T> c);
}
