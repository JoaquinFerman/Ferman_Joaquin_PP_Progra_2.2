package modelo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Libro implements Comparable<Libro>, CSVSerializable<Libro> {
    private int id;
    private String autor;
    private String titulo;
    private Categoria categoria;
    
    public Libro(int id, String titulo, String autor, Categoria categoria){
        this.id = id;
        this.autor = autor;
        this.titulo = titulo;
        this.categoria = categoria;
    }

    public int getId(){ return id; }
    public String getTitulo(){ return titulo; }
    public Categoria getCategoria(){ return categoria; }

    @Override
    public int compareTo(Libro obj){
        return Integer.compare(id, obj.getId());
    }

    @Override
    public void toCSV(String path){
        File file = new File(path);

        try{
            if(file.exists()){
                System.out.println("File already exists");
            }else{
                file.createNewFile();
            }
        } catch (IOException ex){
            System.out.println("Error while creating file");
        }

        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write(this.toStringCSV() + "\n");
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    private String toStringCSV(){
        return String.format("%d,%s,%s,%s", id, titulo, autor, categoria);
    }

    public static Libro fromCSV(String line){
        String[] data = line.split(",");
        Libro toReturn = new Libro(Integer.parseInt(data[0]), data[1], data[2], Categoria.valueOf(data[3].toUpperCase()));
        return toReturn;
    }

    @Override
    public String toString(){
        return String.format("{id:%d, titulo:%s, autor:%s, categoria:%s}", id, titulo, autor, categoria);
    }
}
