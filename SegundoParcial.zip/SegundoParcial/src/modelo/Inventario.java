package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class Inventario<T extends CSVSerializable<T> & Comparable<T>>{
    // hice que solo puedan ser comparables para evitarme problemas
    List<T> elementos;

    public Inventario(){
        this.elementos = new ArrayList<>();
    }

    public void agregar(T obj){
        elementos.add(obj);
    }

    public T get(int i){
        return elementos.get(i);
    }

    public void remove(int i){
        elementos.remove(i);
    }

    public void ordenar(Comparator<T> comp){
        Collections.sort(elementos, comp);
    }

    public void ordenar(){
        Collections.sort(elementos);
        // Iba a usar el sort normal pero no aparecia disponible el sort sin entrada de comparator
    }

    public void paraCadaElemento(Consumer<T> accion){
        for(T obj : elementos){
            accion.accept(obj);
        }
    }

    public List<T> filtrar(Predicate<T> comp){
        List<T> aux = new ArrayList<>();
        for(T obj : elementos){
            if(comp.test(obj)){
                aux.add(obj);
            }
        }
        return aux;
    }

    public void guardarEnCSV(String path){
        File file = new File(path);

        try{
            if(file.exists()){
                System.out.println("File already exists");
            }else{
                file.createNewFile();
            }
        } catch (IOException ex){
            System.out.println("Error while creating file");
        }

        for(T obj : elementos){
            obj.toCSV(path);
        }
    }

    public List<Libro> cargarDesdeCSV(String path){
        List<Libro> toReturn = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(path))){
            String line;
            while((line = br.readLine()) != null){
                if(line.endsWith("\n")){
                    line = line.substring(line.length()-1);
                }
                
                Libro obj = Libro.fromCSV(line);
                toReturn.add(obj);
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }

    public void guardarEnArchivo(String path){
    try(FileOutputStream file = new FileOutputStream(path);
        ObjectOutputStream out = new ObjectOutputStream(file)){
            out.writeObject(this);
        } catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    public Inventario<T> cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException{
        try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            Inventario<T> obj = (Inventario<T>) input.readObject();
            System.out.println("Objeto recuperado");
            return obj;

        } catch(IOException ex){
            throw new IOException();
        } catch(ClassNotFoundException ex){
            throw new ClassNotFoundException();
        }
    }
}
