package modelo;

public interface CSVSerializable<T> {
    void toCSV(String path);
}
